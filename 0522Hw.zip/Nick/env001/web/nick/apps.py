from django.apps import AppConfig


class NickConfig(AppConfig):
    name = 'nick'
